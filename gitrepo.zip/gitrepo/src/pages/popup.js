function Popup(){
    return (
        <div className="Popup">
            <main>
                <h1>React Popups</h1>
            </main>
        </div>
    )
}

export default Popup;