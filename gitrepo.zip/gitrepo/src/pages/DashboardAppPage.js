import { Helmet } from 'react-helmet-async';
import { faker } from '@faker-js/faker';
import { useState, useEffect } from 'react';
import Overlay from "react-overlay-component";
import { useNavigate } from 'react-router-dom';
import { LoadingButton } from '@mui/lab';
// @mui
import { useTheme } from '@mui/material/styles';
import { Grid, Container, Typography, Button, TextField } from '@mui/material';
// components
import Iconify from '../components/iconify';
// sections
import {
  AppTasks,
  AppNewsUpdate,
  AppOrderTimeline,
  AppCurrentVisits,
  AppWebsiteVisits,
  AppTrafficBySite,
  AppWidgetSummary,
  AppCurrentSubject,
  AppConversionRates,
} from '../sections/@dashboard/app';

// ----------------------------------------------------------------------

export default function DashboardAppPage() {
  const navigate = useNavigate();
  const theme = useTheme();
  const [data,setData] = useState([{}])
  const [prices, setPrice] = useState([{}]);
  const [toDel, settoDel] = useState('');

  const handleItem= () => {
    Object.keys(data).map((key, index) => {
      return {label:`${key}`, value:data[key][0]}
    })
  };
  const [children, setChildren] = useState('');
  const [isOpen1, setOverlay1] = useState(false);
  const [isOpen2, setOverlay2] = useState(false);
  const [isOpen3, setOverlay3] = useState(false);
  const [isOpen4, setOverlay4] = useState(false);
  const [isOpen5, setOverlay5] = useState(false);
    const closeOverlay1 = () => setOverlay1(false);
    const closeOverlay2 = () => setOverlay2(false);
    const closeOverlay3 = () => setOverlay3(false);
    const closeOverlay4 = () => setOverlay4(false);
    const closeOverlay5 = () => setOverlay5(false);
    const configs = {
        animate: true,
        // clickDismiss: false,
        // escapeDismiss: false,
        // focusOutline: false,
    };
    const handleClick = () => {
      fetch('http://127.0.0.1:8000/post_insurance_plan', {
        method: 'POST',
        cache: 'no-cache',
        headers: {
            content_type: 'application/json',
            },
            body: JSON.stringify(`${children}`),
          }).then(response => response.json()).then(setTimeout(() => { navigate('/dashboard', { replace: true }).then(
            navigate('/dashboard/app', { replace: true })
            )
  }, 1000),
        )
          .catch(error => console.log(error));
          setOverlay5(false);
          

    };

    const handleClick2 = () => {
      fetch('http://127.0.0.1:8000/delete_plan', {
        method: 'POST',
        cache: 'no-cache',
        headers: {
            content_type: 'application/json',
            },
            body: JSON.stringify(`${toDel}`),
          }).then(response => response.json()).then(setTimeout(() => { navigate('/dashboard', { replace: true }).then(
              navigate('/dashboard/app', { replace: true })
            )
  }, 1000),
        )
          .catch(error => console.log(error));
          setOverlay2(false);
          

    };

  useEffect(() => {
    fetch("http://127.0.0.1:8000/current_plans").then(
      res=>res.json()
    ).then(
      data=>{
        setData(data)
      }
    )
  },[])
  return (
    <>
      <Helmet>
        <title> Dashboard | Minimal UI </title>
      </Helmet>

      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Welcome back!
        </Typography>

        <Grid container spacing={3}>
          {
            Object.keys(data).map((key, index) => {
              if(`${key}`.includes("health")){
                return <Grid item xs={12} sm={6} md={3} key={index}>
                <AppWidgetSummary title={key} total={data[key][0]} color="error" icon={'ant-design:heart-outlined'} />
                <Button onClick={() => {setOverlay1(true);}} style={{justifyContent:'center',}}>Expand Plan</Button>
            <Overlay configs={configs} isOpen={isOpen1} closeOverlay={closeOverlay1}>
            <h2>This is the cost for your insurance from State Farm. Your next payment is due on {data[key][1]}. Please regularly monitor the Products section, so you dont miss out on the best deals!</h2>
                <p> This is a full coverage plan</p>
                <Button
                    onClick={() => {
                        setOverlay1(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
            <Button onClick={() => {setOverlay4(true);settoDel(key)}} style={{justifyContent:'center',}}>Cancel Plan</Button>
            <Overlay configs={configs} isOpen={isOpen4} closeOverlay={closeOverlay4}>
            <h2>Are you sure you want to cancel this plan?</h2>
               

                <Button
                    onClick={() => {
                        setOverlay4(false);
                        handleClick2();
                    }}
                >
                    Yes, Cancel it
                </Button>
            </Overlay>
              </Grid>
            }
             if (`${key}`.includes("auto") || `${key}`.includes("car")){
            return <Grid item xs={12} sm={6} md={3} key={index}>
                <AppWidgetSummary title={key} total={data[key][0]} color="warning" icon={`ant-design:car-outlined`} />
                <Button onClick={() => {setOverlay2(true);}} style={{justifyContent:'center',}}>Expand Plan</Button>
            <Overlay configs={configs} isOpen={isOpen2} closeOverlay={closeOverlay2}>
                <h2>This is the cost for your insurance from AllState. Your next payment is due on {data[key][1]}. Please regularly monitor the Products section, so you dont miss out on the best deals!</h2>
                <p> This is a minimum coverage plan</p>
                <Button
                    onClick={() => {
                        setOverlay1(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
            <Button onClick={() => {setOverlay4(true); settoDel(key)}} style={{justifyContent:'center',}}>Cancel Plan</Button>
            <Overlay configs={configs} isOpen={isOpen4} closeOverlay={closeOverlay4}>
            <h2>Are you sure you want to cancel this plan?</h2>
               

                <Button
                    onClick={() => {
                        setOverlay4(false);
                        handleClick2();
                    }}
                >
                    Yes, Cancel it
                </Button>
            </Overlay>
          </Grid>}
          return <Grid item xs={12} sm={6} md={3} key={index}>
          <AppWidgetSummary title={key} total={data[key][0]} color="info" icon={`ant-design:home-outlined`} />
          <Button onClick={() => {setOverlay3(true);}} style={{justifyContent:'center',}}>Expand Plan</Button>
            <Overlay configs={configs} isOpen={isOpen3} closeOverlay={closeOverlay3}>
            <h2>This is the cost for your insurance from GEICO. Your next payment is due on {data[key][1]}. Please regularly monitor the Products section, so you dont miss out on the best deals!</h2>
                <p> This is a full coverage plan</p>
                <Button
                    onClick={() => {
                        setOverlay1(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
            <Button onClick={() => {setOverlay4(true); settoDel(key)}} style={{justifyContent:'center',}}>Cancel Plan</Button>
            <Overlay configs={configs} isOpen={isOpen4} closeOverlay={closeOverlay4}>
            <h2>Are you sure you want to cancel this plan?</h2>
               

                <Button
                    onClick={() => {
                        setOverlay4(false);
                        handleClick2();
                    }}
                >
                    Yes, Cancel it
                </Button>
            </Overlay>
    </Grid>
})
          }

            <Grid item xs={12} sm={6} md={3} key={"5000000"}>
                
                <AppWidgetSummary title={"Add Insurance"}  icon={'ant-design:plus-outlined'} />
                <Button onClick={() => {setOverlay5(true);}} style={{justifyContent:'center',}}>Add Insurance</Button>
            <Overlay configs={configs} isOpen={isOpen5} closeOverlay={closeOverlay5}>
            <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             Which insurance would you like to purchase?
            </Typography>
            <p> </p>
            <select value={children} onChange={e => setChildren(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
            <option value="0">Which insurance would you like to purchase?</option>
            <option value="health">Health Insurance</option>
              <option value="home">Home Insurance</option>
              <option value="auto">Auto Insurance</option>
            </select>
            <p> </p>
            <Typography variant="h8" sx={{ px: 2, mt: -1, mb: -1 }}>
             What is your current insurance quote?
            </Typography>
            <p> </p>
            <TextField name="mileage" label="Please enter the value in format" onChange={null}/>
            <p> </p>

            <Typography variant="h8" sx={{ px: 2, mt: -1, mb: -1 }}>
             When is your monthly payment due?
            </Typography>
            <p> </p>
            <TextField name="mileage" label="Please enter the value in format" onChange={null}/>

            <p> </p>
            <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
             Submit
            </LoadingButton>
            <p> </p>
                <Button
                    onClick={() => {
                        setOverlay5(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
              </Grid>

          <Grid item xs={12} md={6} lg={8}>
            <AppWebsiteVisits
              title="Dow Jones Industrial Average"
              subheader="(+12.35%) than last month"
              chartLabels={[
                '11/11/2022',
                '11/10/2022',
                '11/9/2022',
                '11/8/2022',
                '11/7/2022',
                '11/6/2022',
                '11/5/2022',
                '11/4/2022',
                '11/3/2022',
                '11/2/2022',
                '11/1/2022',
                
              ]}
              chartData={[
                {
                  name: 'Team A',
                  type: 'column',
                  fill: 'solid',
                  data: [32861.8, 32732.95, 32653.2, 32147.76, 32001.25, 32403.22, 32403.22, 32403.22, 32827.0, 33160.83, 32513.94, 33715.37, 33747.86],
                }
              ]}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={4}>
            <AppCurrentVisits
              title="Current Split"
              chartData={Object.keys(data).map((key, index) => {
                return {label:`${key}`, value:data[key][0]}
              })}
              chartColors={[
                theme.palette.primary.main,
                theme.palette.info.main,
                theme.palette.warning.main,
                theme.palette.error.main,
              ]}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={8}>
            <AppWebsiteVisits
              title="S&P 500"
              subheader="(+8.80%) than last month"
              chartLabels={[
                '11/11/2022',
                '11/10/2022',
                '11/9/2022',
                '11/8/2022',
                '11/7/2022',
                '11/6/2022',
                '11/5/2022',
                '11/4/2022',
                '11/3/2022',
                '11/2/2022',
                '11/1/2022',
                
              ]}
              chartData={[
                {
                  name: 'Price',
                  type: 'column',
                  fill: 'solid',
                  data: [3901.79, 3852.90, 3733.25, 3766.98, 3766.98, 3766.98, 3780.71, 3817.02, 3810.94, 3859.89, 3963.72],
                }
              ]}
            />
          </Grid>


          <Grid item xs={12} md={6} lg={4}>
            <AppOrderTimeline
              title="Latest Deals"
              list={[...Array(5)].map((_, index) => ({
                id: faker.datatype.uuid(),
                title: [
                  '$200 off house insurance first month - State Farm',
                  'Students get free checking and savings accounts - Capital One',
                  '$50 off signing fees for any new loan - BoA',
                  'No annual fee for international credit card - Chase',
                  'Competitive interest rates for housing loans - Wells Fargo',
                ][index],
                type: `order${index + 1}`,
                time: faker.date.past(),
              }))}
            />
          </Grid>

        </Grid>
      </Container>
    </>
  );
}
