import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Overlay from "react-overlay-component";
// @mui
import { Link, Stack, IconButton, InputAdornment, TextField, Checkbox, Typography, Button } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../../components/iconify';

// ----------------------------------------------------------------------

export default function CarEstimate() {
  const navigate = useNavigate();
  const [carEstimate, setEstimate] = useState('');
  const [year, setYear] = useState('');
  const [brand, setBrand] = useState('');
  const [milleage, setM] = useState('');
  const [age, setAge] = useState('');
  const [children, setChildren] = useState('');
  const [income, setIncome] = useState('');
  const [dui, setDui] = useState('');
  const [accidents, setAccidents] = useState('');
  const [isOpen1, setOverlay1] = useState(false);
  const closeOverlay1 = () => setOverlay1(false);
  const configs = {
    animate: true,
    // clickDismiss: false,
    // escapeDismiss: false,
    // focusOutline: false,
  };
  const handleClick = () => {
    new Promise((r) => setTimeout(r, 500));
    fetch('http://127.0.0.1:8000/insurance_quote_car', {
      method: 'POST',
      cache: 'no-cache',
      headers: {
          content_type: 'application/json',
          },
          body: JSON.stringify(`${brand} ${year} ${milleage} ${age} ${children} ${dui} ${accidents}`),
        }).then(response => response.json())
        .then(response => setEstimate(response))
        .catch(error => console.log(error));
        setOverlay1(true);
  };

  return (
    <>
      <Stack spacing={3}>
      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
             Select your Car make
      </Typography>
      <select value={brand} onChange={e => setBrand(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="None">Select Car Brand</option>
      <option value="Honda">Honda</option>
      <option value="Toyota">Toyota</option>
      <option value="Lexas">Lexas</option>
      <option value="BMW">BMW</option>
      <option value="Mercedes">Mercedes</option>
      <option value="Ferrari">Ferrari</option>
      <option value="Tesla">Tesla</option>
      <option value="Audi">Audi</option>
      <option value="Acura">Acura</option>
      <option value="Nissan">Nissan</option>
      <option value="Hyundi">Hyundi</option>
      <option value="Other">Other</option>
      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
        Select the year your car was made
      </Typography>
      <select value={year} onChange={e => setYear(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="2000">Year</option>
      <option value="2000">2000</option>
      <option value="2001">2001</option>
      <option value="2002">2002</option>
      <option value="2003">2003</option>
      <option value="2004">2004</option>
      <option value="2005">2005</option>
      <option value="2006">2006</option>
      <option value="2007">2007</option>
      <option value="2008">2008</option>
      <option value="2009">2009</option>
      <option value="2010">2010</option>
      <option value="2011">2011</option>
      <option value="2012">2012</option>
      <option value="2013">2013</option>
      <option value="2014">2014</option>
      <option value="2015">2015</option>
      <option value="2016">2016</option>
      <option value="2017">2017</option>
      <option value="2018">2018</option>
      <option value="2019">2019</option>
      <option value="2020">2020</option>
      <option value="2021">2021</option>
      <option value="2022">2022</option>
      <option value="2023">2023</option>
      <option value="Other">Other</option>
      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
        Please type in your car's current mileage
      </Typography>
      <TextField name="mileage" label="Please enter the mileage" onChange={e => setM(e.target.value)}/>
<p> </p>
<Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
        Please type in your age
      </Typography>
      <TextField name="Age" label="Please enter your Age" onChange={e => setAge(e.target.value)}/>
<p> </p>
      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             How many children do you have?
      </Typography>
      <select value={children} onChange={e => setChildren(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="-1">Select number of children</option>
       <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4+</option>

      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             Select the income range that includes your annual income
      </Typography>

      <select value={income} onChange={e => setIncome(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
       <option value="1">Select Income Range</option>
       <option value="2">$0-$5,000</option>
       <option value="3">$5,001 -$10,000</option>
       <option value="4">$10,001 -$15,0000</option>
       <option value="5">$10,001-$20,000</option>
       <option value="6">$20,001-$30,000</option>
       <option value="7">$30,001-$40,000</option>
       <option value="8">$40,001-$50,000</option>
       <option value="9">$50,001-$60,000</option>
       <option value="10">$60,001-$70,000</option>
       <option value="11">$70,001-$80,000</option>
       <option value="12">$80,001-$90,000</option>
       <option value="13">$90,001-$100,000</option>
       <option value="14">$100,001-$150,000</option>
       <option value="15">$150,001-$200,000</option>
       <option value="16">$200,001-$300,000</option>
       <option value="17">$300,001+</option>
      </select>

      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             How many duis do you have?
      </Typography>
      <select value={dui} onChange={e => setDui(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="-1">Select number of children</option>
       <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4+</option>

      </select>
      <p> </p>
      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             How many accidents have you been at fault for?
      </Typography>
      <select value={accidents} onChange={e => setAccidents(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="-1">Select number of children</option>
       <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4+</option>

      </select>
      <p> </p>
      </Stack>
      <p>  </p>
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Submit
        <Overlay configs={configs} isOpen={isOpen1} closeOverlay={closeOverlay1}>
            <h1 style={{color:'black'}}>This is the estimated quote for your auto insurance: ${carEstimate}</h1>
                <p> This is a full coverage plan</p>
                <Button
                    onClick={() => {
                        setOverlay1(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
      </LoadingButton>
    </>
  );
}
