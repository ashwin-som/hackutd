import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Overlay from "react-overlay-component";
// @mui
import { Link, Stack, IconButton, InputAdornment, TextField, Checkbox, Typography, Button } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../../components/iconify';

// ----------------------------------------------------------------------

export default function LoginForm2() {
  const navigate = useNavigate();
  const [healthEstimate, setEstimate] = useState('');
  const [age, setAge] = useState('');
  const [sex, setSex] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [children, setChildren] = useState('');
  const [smoker, setSmoker] = useState('');
  const [income, setIncome] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isOpen1, setOverlay1] = useState(false);
  const closeOverlay1 = () => setOverlay1(false);
  const configs = {
    animate: true,
    // clickDismiss: false,
    // escapeDismiss: false,
    // focusOutline: false,
  };
  const handleClick = () => {
    new Promise((r) => setTimeout(r, 500));
    fetch('http://127.0.0.1:8000/get_health_insurance_quote', {
      method: 'POST',
      cache: 'no-cache',
      headers: {
          content_type: 'application/json',
          },
          body: JSON.stringify(`${age} ${sex} ${weight} ${height} ${children} ${smoker}`),
        }).then(response => response.json())
        .then(response => setEstimate(response))
        .catch(error => console.log(error));
        setOverlay1(true);
  };

  return (
    <>
      <Stack spacing={3}>
      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
        Please type in your age
      </Typography>
      <TextField name="Age" label="Please enter your Age" onChange={e => setAge(e.target.value)}/>
<p> </p>
      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
             Select your gender
      </Typography>
      <select value={sex} onChange={e => setSex(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="1">Select Gender</option>
      <option value="2">Male</option>
      <option value="3">Female</option>
        <option value="4">Other</option>
      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -2, mb: -2 }}>
             Enter your weight in lbs (to the nearest whole number)
      </Typography>
      <TextField name="Weight" label="Please enter your Weight" onChange={e => setWeight(e.target.value)}/>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             Enter your height in the following format: (5ft 1in)
      </Typography>
      <TextField name="Height" label="Please enter your Height" onChange={e => setHeight(e.target.value)}/>
      <p> </p>


      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             How many children do you have?
      </Typography>
      <select value={children} onChange={e => setChildren(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="-1">Select number of children</option>
       <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4+</option>

      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             Please enter your experience with smoking of any kind
      </Typography>
      <select value={smoker} onChange={e => setSmoker(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
      <option value="1">Select Smoking option</option>
      <option value="3">I do not smoke, and have not smoked in the past</option>
      <option value="2">I do not smoke, but smoked in the past</option>
        <option value="4">I do smoke</option>
      </select>
      <p> </p>

      <Typography variant="h6" sx={{ px: 2, mt: -1, mb: -1 }}>
             Select the income range that includes your annual income
      </Typography>

      <select value={income} onChange={e => setIncome(e.target.value)} style={{height : 55, backgroundColor: '#FAFAFA'}}>
       <option value="1">Select Income Range</option>
       <option value="2">$0-$5,000</option>
       <option value="3">$5,001 -$10,000</option>
       <option value="4">$10,001 -$15,0000</option>
       <option value="5">$10,001-$20,000</option>
       <option value="6">$20,001-$30,000</option>
       <option value="7">$30,001-$40,000</option>
       <option value="8">$40,001-$50,000</option>
       <option value="9">$50,001-$60,000</option>
       <option value="10">$60,001-$70,000</option>
       <option value="11">$70,001-$80,000</option>
       <option value="12">$80,001-$90,000</option>
       <option value="13">$90,001-$100,000</option>
       <option value="14">$100,001-$150,000</option>
       <option value="15">$150,001-$200,000</option>
       <option value="16">$200,001-$300,000</option>
       <option value="17">$300,001+</option>
      </select>
      </Stack>
      <p>  </p>
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Submit
        <Overlay configs={configs} isOpen={isOpen1} closeOverlay={closeOverlay1}>
            <h1 style={{color:'black'}}>This is the estimated quote for your health insurance: ${healthEstimate}</h1>
                <p> This is a full coverage plan</p>
                <Button
                    onClick={() => {
                        setOverlay1(false);
                    }}
                >
                    Back to Home
                </Button>
            </Overlay>
      </LoadingButton>
      
    </>
  );
}
